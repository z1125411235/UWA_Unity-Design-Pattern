# Screen Shot
![](objectPoolScreenShot.png)

# Reference

https://www.assetstore.unity3d.com/cn/?stay#!/content/31928




