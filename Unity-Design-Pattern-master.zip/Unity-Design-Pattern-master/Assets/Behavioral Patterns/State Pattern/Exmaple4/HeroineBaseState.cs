﻿//-------------------------------------------------------------------------------------
//	HeroineBaseState.cs
//-------------------------------------------------------------------------------------

using UnityEngine;
using System.Collections;

public interface HeroineBaseState
{
    void Update();
    void HandleInput();

}
